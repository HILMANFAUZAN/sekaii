<?php 
$koneksi = mysqli_connect("localhost", "root", "", "mann22");